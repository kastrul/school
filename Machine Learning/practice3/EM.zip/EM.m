% this script is to implement EM algorithm. 

%generate sets 
clear
clc

% covariance matrices
c(1).matrix = [4, 2; 2, 3];
c(2).matrix = [2, -2; -2, 6];
c(3).matrix = [1, -0.5; -0.5, 1];

% mean values
mu(1,:) = [2,0];
mu(2,:) = [12,0];
mu(3,:) = [-1,-10];

% sample sizes
n(1) = 500;
n(2) = 700;
n(3) = 600;

DD=[];
for i=1:3
    D(i).set = mvnrnd(mu(i,:),c(i).matrix,n(i)); 
    DD=[DD;D(i).set];
end

fh(1) = figure(1);
clf(fh(1))
for i=1:3
    scatter(D(i).set(:,1),D(i).set(:,2))
    hold on
end

K=3; % this is number of clusters 
[rows,~] =size(DD);
% Now let us fit the gaussians
% intialize
Pi=ones(K)*1/3; % for each point we say equal weights to belong to each class
estim_mu=randn(K,2);
c_estim(1).matrix =[1,3;4,2]*[3,0 ;0, 2]*[1,3;4,2]';
c_estim(2).matrix =[1,3;4,2]*[3,0 ;0, 2]*[1,3;4,2]';
c_estim(3).matrix =[1,3;4,2]*[3,0 ;0, 2]*[1,3;4,2]';


%now start mayn loop
exit_flag=0;

while exit_flag==0
    %recompute responsibilities
    for i=1:rows
        for j=1:K
            tau(i,j) = Pi(j)*mvnpdf(DD(i,:),estim_mu(j,:),c_estiom(j).matrix);
        end
        % have to check this place
    end
    
    % M step
    for j=1:K
        Pi(j)=sum(r(:,j))/rows;
        estim_mu(k,:)=
        
end

            
    



